﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Windows;
using System.Windows.Controls;

// Add these two aliases to resolve the ambiguity:
using Button = System.Windows.Controls.Button;
using MessageBox = System.Windows.MessageBox;

namespace SimTools_v4
{
    // Interaction logic for MainWindow.xaml
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // Context menu handling, so event handlers don't fire off early when the XAML is loading
            SetupGPUContextMenu();
            SetupTweakContextMenu();
        }

        // Routes user to the vanilla demo video on YouTube
        private void TS3Vanilla_Click(object? sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Name == "TS3Vanilla")
            {
                OpenUrl("https://www.youtube.com/watch?v=WvsPzENc8Ps");
            }
        }

        // Routes user to the SimTools demo video on YouTube
        private void WithSimTools_Click(object? sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Name == "TS3WithSimTools")
            {
                OpenUrl("https://www.youtube.com/watch?v=hLXq3eVV1Eo");
            }
        }

        // Helper method to open URLs in the default web browser
        private static void OpenUrl(string url)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                };
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unable to open link: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Routes user to the video tutorial on YouTube
        private void VideoTutorial_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Name == "VideoTutorial")
            {
                OpenUrl("https://www.youtube.com/watch?v=IkewLXsy-CA");
            }
        }

        // User clicked the "New GPU" button, show a warning message box
        private void NewGPUButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"This page has been converted into a menu. Please right-click the button to view the options.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        // Context menu event handler for the "New GPU" button
        // Build the menu ONCE at startup — fixes the immediate-launch bug
        private void SetupGPUContextMenu()
        {
            var contextMenu = new ContextMenu();

            // ── The Sims 2 (sub-menu) ──────────────────────────────────────────
            var sims2Item = new MenuItem { Header = "The Sims 2" };

            var sims2_32 = new MenuItem { Header = "32-Bit" };
            sims2_32.Click += (s, args) => DownloadAndOpenExe(
                url: "https://www.simsnetwork.com/files/graphicsrulesmaker/graphicsrulesmaker-2.3.0-32bit.exe",  // ← replace
                fileName: "graphicsrulesmaker-2.3.0-32bit.exe",
                downloadDirectory: Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "install")
            );

            var sims2_64 = new MenuItem { Header = "64-Bit" };
            sims2_64.Click += (s, args) => DownloadAndOpenExe(
                url: "https://www.simsnetwork.com/files/graphicsrulesmaker/graphicsrulesmaker-2.3.0-64bit.exe",  // ← replace
                fileName: "graphicsrulesmaker-2.3.0-64bit.exe",
                downloadDirectory: Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "install")
            );

            sims2Item.Items.Add(sims2_32);
            sims2Item.Items.Add(sims2_64);

            // ── The Sims Stories (sub-menu) ────────────────────────────────────
            var simsStoriesItem = new MenuItem { Header = "The Sims Stories" };

            var simsStories_32 = new MenuItem { Header = "32-Bit" };
            simsStories_32.Click += (s, args) => DownloadAndOpenExe(
                url: "https://www.simsnetwork.com/files/graphicsrulesmaker/graphicsrulesmaker-2.3.0-32bit.exe",  // ← replace
                fileName: "graphicsrulesmaker-2.3.0-32bit.exe",
                downloadDirectory: Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "install")
            );

            var simsStories_64 = new MenuItem { Header = "64-Bit" };
            simsStories_64.Click += (s, args) => DownloadAndOpenExe(
                url: "https://www.simsnetwork.com/files/graphicsrulesmaker/graphicsrulesmaker-2.3.0-64bit.exe",  // ← replace
                fileName: "graphicsrulesmaker-2.3.0-64bit.exe",
                downloadDirectory: Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "install")
            );

            simsStoriesItem.Items.Add(simsStories_32);
            simsStoriesItem.Items.Add(simsStories_64);

            // ── The Sims 3 (no sub-menu) ───────────────────────────────────────
            var sims3Item = new MenuItem { Header = "The Sims 3" };
            sims3Item.Click += (s, args) => DownloadAndOpenExe(
                url: "https://repo.ts3tools.com/bin/x86/TS3_GPU_Addon.exe",  // ← replace
                fileName: "TS3_GPU_Addon.exe",
                downloadDirectory: Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "install")
            );

            contextMenu.Items.Add(sims2Item);
            contextMenu.Items.Add(simsStoriesItem);
            contextMenu.Items.Add(sims3Item);

            NewGPUButton.ContextMenu = contextMenu;
        }

        // Handler is now empty — menu is pre-built, nothing to do here
        private void NewGPUButton_Context(object sender, ContextMenuEventArgs e) { }

        // ── Helper: download only if missing, then launch ─────────────────────────
        private async void DownloadAndOpenExe(string url, string fileName, string downloadDirectory)
        {
            // Create the directory if it doesn't exist yet
            Directory.CreateDirectory(downloadDirectory);

            string exePath = Path.Combine(downloadDirectory, fileName);

            if (!File.Exists(exePath))
            {
                var progressWindow = new DownloadProgressWindow(fileName)
                {
                    Owner = System.Windows.Application.Current.MainWindow
                };
                progressWindow.Show();

                try
                {
                    using var http = new HttpClient();
                    using var response = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
                    response.EnsureSuccessStatusCode();

                    long? totalBytes = response.Content.Headers.ContentLength;

                    await using var contentStream = await response.Content.ReadAsStreamAsync();
                    await using var fileStream = new FileStream(
                        exePath, FileMode.Create, FileAccess.Write, FileShare.None, 8192, true);

                    var buffer = new byte[8192];
                    long bytesRead = 0;
                    int lastPercent = 0;
                    int chunk;

                    while ((chunk = await contentStream.ReadAsync(buffer)) > 0)
                    {
                        await fileStream.WriteAsync(buffer.AsMemory(0, chunk));
                        bytesRead += chunk;

                        if (totalBytes.HasValue)
                        {
                            int percent = (int)(bytesRead * 100 / totalBytes.Value);
                            if (percent != lastPercent)
                            {
                                lastPercent = percent;
                                progressWindow.UpdateProgress(percent);
                            }
                        }
                        else
                        {
                            progressWindow.SetIndeterminate();
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (File.Exists(exePath))
                        File.Delete(exePath);

                    progressWindow.Close();

                    System.Windows.MessageBox.Show(
                        $"Download failed for {fileName}:\n{ex.Message}",
                        "Download Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                    return;
                }
                finally
                {
                    progressWindow.Close();
                }
            }

            Process.Start(new ProcessStartInfo(exePath) { UseShellExecute = true });
        }

        // User clicked the Tweaks button, show a warning message box
        private void TweakButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"This page has been converted into a menu. Please right-click the button to view the options.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void SetupTweakContextMenu()
        {
            var contextMenu = new ContextMenu();

            // ── The Sims 1 (sub-menu) ──────────────────────────────────────────
            var sims1Item = new MenuItem { Header = "The Sims 1" };

            // ── Simitone ──────────────────────────────────────────
            var sims1_simitone = new MenuItem { Header = "Simitone" };
            sims1_simitone.Click += (s, args) => DownloadAndOpenExe(
                url: "https://github.com/riperiperi/Simitone/releases/download/v0.8.12/SimitoneWindows.zip",  // ← replace
                fileName: "SimitoneWindows.zip",
                downloadDirectory: Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "install")
            );

            sims1Item.Items.Add(sims1_simitone);

            contextMenu.Items.Add(sims1Item);

            TweakButton.ContextMenu = contextMenu;
        }

        // Handler is now empty — menu is pre-built, nothing to do here
        private void TweakButton_Context(object sender, ContextMenuEventArgs e) { }
        }
    }